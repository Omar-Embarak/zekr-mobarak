package com.hmz.al_quran

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
