### Privacy Policy
The Holy Qur'an App

As per this application there is no such personal information that is being collected on user's behalf. The app is just connected to internet and other information which is collected could be from Google Analytics.

If you want to request details you can contact Google play support as far as developer is concerned there is no collection of data.

Also there is no third party collecting user's data per this application.