class AppRoutes {
// This is an auto generated file. Do not make any change on this.

  static const home = 'home';
  static const page = 'page';
  static const shareApp = 'shareApp';
  static const splash = 'splash';
  static const surah = 'surah';
  static const bookmarks = 'bookmarks';
  static const juz = 'juz';
  static const onboarding = 'onboarding';
}
